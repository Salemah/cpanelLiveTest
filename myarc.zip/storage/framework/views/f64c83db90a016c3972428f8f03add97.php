    <div id="topbar" class="text-white bg-color">
        <div class="container">
            <div class="topbar-left sm-hide">
                <span class="topbar-widget tb-social">
                    <a href="<?php if($dashboard_settings): ?> <?php echo e($dashboard_settings->facebook); ?> <?php endif; ?>"><i class="fa fa-facebook"></i></a>
                    <a href="<?php if($dashboard_settings): ?> <?php echo e($dashboard_settings->twitter); ?> <?php endif; ?>"><i class="fa fa-twitter"></i></a>
                    <a href="<?php if($dashboard_settings): ?> <?php echo e($dashboard_settings->instagram); ?> <?php endif; ?>"><i class="fa fa-instagram"></i></a>
                </span>
            </div>
            
            <div class="clearfix"></div>
        </div>
    </div>
<?php /**PATH D:\laragon\www\myarc\resources\views/frontend/layers/topbar.blade.php ENDPATH**/ ?>