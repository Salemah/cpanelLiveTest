<img src="<?php if($dashboard_settings): ?> <?php echo e(asset('/image/dashboard/' . $dashboard_settings->logo)); ?> <?php else: ?>  <?php echo e(asset('logo2.png')); ?> <?php endif; ?>"
    alt="Logo" style="height: 100px;">
<?php /**PATH D:\laragon\www\myarc\resources\views/components/application-logo.blade.php ENDPATH**/ ?>