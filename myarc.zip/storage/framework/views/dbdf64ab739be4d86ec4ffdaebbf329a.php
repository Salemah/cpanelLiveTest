<?php $__env->startSection('css'); ?>
    <style>
        .pagination .page-item .page-link {
            padding: 10px 15px;
            margin: 0 5px;
            border-radius: 5px;
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
        }

        .pagination .page-item.active .page-link {
            background-color: #EAA636;
            color: white;
            border-color: #007bff;
        }

        .pagination .page-item .page-link:hover {
            background-color: #e9ecef;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('top_bar'); ?>
    <?php echo $__env->make('frontend.layers.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('frontend.layers.transparent_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- section begin -->
    <section id="subheader" class="jarallax text-white">
        <img src="<?php echo e(asset('images/background/subheader.jpg')); ?>" class="jarallax-img" alt="">
        <div class="center-y relative text-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h1>News</h1>
                        <p>Reputation. Respect. Result.</p>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- section close -->
    <!-- section begin -->

    <section aria-label="section">
        <div class="container">
            <div class="row">

                <?php if($Articles): ?>
                    <?php $__empty_1 = true; $__currentLoopData = $Articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-lg-4 col-md-6 mb30">
                            <a href="<?php echo e(route('frontend.articles.details',['id' => $article->id])); ?>">
                                <div class="bloglist item">
                                    <div class="post-content">
                                        <div class="date-box">
                                            <div class="m"><?php echo e(\Carbon\CarboN::parse($article->date)->format('d')); ?>

                                            </div>
                                            <div class="d"><?php echo e(\Carbon\Carbon::parse($article->date)->format('M')); ?>

                                            </div>
                                        </div>
                                        <div class="post-image">
                                            <img alt="<?php echo e($article->title); ?>" src="<?php echo e(asset($article->image)); ?>">
                                        </div>
                                        <div class="post-text">
                                            <span class="p-tagline"><?php echo e($article->LegalArea->lawCategory ? $article->LegalArea->lawCategory->name : 'Law Firm'); ?></span>
                                            <h4><?php echo e($article->title); ?><span></span></h4>
                                            <p><?php echo \Illuminate\Support\Str::limit($article->description, 100); ?></p>
                                            <span class="p-author"><?php echo e($article->User ? $article->User->name : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>

                    <div class="spacer-single"></div>
                    <?php echo e($Articles->links('pagination::bootstrap-4')); ?>

                <?php endif; ?>

                


                
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layers.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\myarc\resources\views/frontend/articles.blade.php ENDPATH**/ ?>