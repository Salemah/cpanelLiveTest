<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
      <div class="">
        <div class="">
            <div class="row">
                <div class="col-sm-16 col-md-16">
                    <div class="card">
                        <div class="card-header align-items-center justify-content-between d-flex">
                            <nav aria-label="breadcrumb" style="margin-top:-10px;">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Home</a></li>

                                    <li class="breadcrumb-item active" aria-current="page">User Role List</li>

                                </ol>
                            </nav>
                            <a href="<?php echo e(route('admin.user-role')); ?>"><button class="btn btn-primary btn-sm UserAddButton" style="float: right;margin-top:-20px;"><i
                                class="fa fa-plus"></i>Add New Role</button></a>
                        </div>
                        
                        <div class="card-block">
                            <div class="table-responsive">
                                <table id="leave_application_table" class="table table-striped table-bordered table-hover"
                                    >
                                    <thead class="bg-primary text-light" >
                                        <tr>
                                            <th  style="color:white">SL</th>
                                            <th style="color:white">Role Name</th>
                                            <th style="color:white">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $role_permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role_permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($role_permission->id); ?></td>
                                            <td style="text-transform:capitalize;"><?php echo e($role_permission->name); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('admin.user-role',['role'=>$role_permission->name])); ?>" class="btn btn-primary"> View</a>
                                            </td>

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {

            $('#leave_application_insert_update').ajaxForm({
                beforeSend: formBeforeSend,
                beforeSubmit: formBeforeSubmit,
                error: formError,
                success: function(responseText, statusText, xhr, $form) {
                    formSuccess(responseText, statusText, xhr, $form);
                    $('#leave_application_table').DataTable().draw(true);
                    $("#LeaveApplicationAdd").modal('hide');
                    $('#hidden-id').setAttribute("disabled");

                },
                clearForm: true,
                resetForm: true
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.backendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\myarc\resources\views/backend/user_role_list.blade.php ENDPATH**/ ?>