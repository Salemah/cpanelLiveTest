
<div class=" mt-4">
        <div class="row justify-content-center">
            <div class="col-sm-12 col-md-6">
                <div class="card">
                    <div class="card-body">
                        <!-- Time Slot Title -->
                        <h5 class="section-title">Time Slot</h5>

                        <!-- Afternoon Section -->
                        <div class="row">
                            <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slots): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-12 col-6">
                                <div class="time-slot">
                                    <h6><?php echo e(\Carbon\Carbon::parse($slots->from_time)->format('g:i A')); ?> - <?php echo e(\Carbon\Carbon::parse($slots->from_time)->addHour()->format('g:i A')); ?></h6>
                                    <p>1 Slots left</p>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php /**PATH D:\laragon\www\myarc\resources\views/frontend/slot_data.blade.php ENDPATH**/ ?>