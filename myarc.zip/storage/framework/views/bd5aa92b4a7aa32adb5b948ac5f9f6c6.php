<?php $__env->startSection('top_bar'); ?>
    <?php echo $__env->make('frontend.layers.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('frontend.layers.transparent_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section id="subheader" class="jarallax text-white">
        <img src="images/background/subheader3.jpg" class="jarallax-img" alt="">
        <div class="center-y relative text-center">
            <div class="container">
                <div class="row">
                    <div class="col text-center">
                        <div class="spacer-single"></div>
                        <h1>FAQ</h1>
                        <p>Reputation. Respect. Result.</p>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- section close -->
    <section id="section-features">
        <div class="container">
            <div class="row">
                <div class="col-md-6 mb30">
                    <div class="box-highlight">
                        <div class="heading text-center text-light">
                            <h3><?php echo e($firstCategory->name); ?></h3>
                        </div>
                        <div class="content">
                            <div class="accordion">
                                <div class="accordion-section">
                                    <?php $__currentLoopData = $firstCategory->faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="accordion-section-title" data-tab="#accordion-<?php echo e($faq->id); ?>">
                                            <?php echo e($faq->question); ?>

                                        </div>
                                        <div class="accordion-section-content" id="accordion-<?php echo e($faq->id); ?>">
                                            <p><?php echo $faq->answer; ?></p>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php $__currentLoopData = $remainingCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 mb30">
                    <div class="box-highlight s2">
                        <div class="heading text-center text-light">
                            <h3><?php echo e($categories->name); ?></h3>
                        </div>
                        <div class="content">
                            <div class="accordion">
                                <div class="accordion-section">
                                    <?php $__currentLoopData = $categories->faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="accordion-section-title" data-tab="#accordion-<?php echo e($faq->id); ?>">
                                            <?php echo e($faq->question); ?>

                                        </div>
                                        <div class="accordion-section-content" id="accordion-<?php echo e($faq->id); ?>">
                                            <p><?php echo $faq->answer; ?></p>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layers.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\myarc\resources\views/frontend/faq.blade.php ENDPATH**/ ?>