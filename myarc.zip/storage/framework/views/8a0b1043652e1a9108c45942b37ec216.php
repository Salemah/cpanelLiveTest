<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="">
            <div class="row">
                <div class="col-sm-12 col-md-12">
                    <div class="card">
                        <div class="card-header align-items-center justify-content-between d-flex">
                            <nav aria-label="breadcrumb" style="margin-top:-10px;">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                                    <li class="breadcrumb-item dropdown-toggle" data-bs-toggle="dropdown"
                                        aria-expanded="false">
                                        Settings</li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        User Role</li>

                                </ol>
                            </nav>
                            <a href="<?php echo e(url('/accounts/user_role_list')); ?>"><button
                                            class="btn btn-primary btn-sm UserAddButton"
                                            style="float: right;margin-top:-20px;"><i
                                                class="fa fa-angle-double-left"></i>User Role List</button></a>
                        </div>
                        
                        <div class="card-block container">
                            <form id="permission_update_form" action="<?php echo e(route('admin.user_role.update')); ?>" method="post"
                                class="form-horizontal">
                                <?php echo e(csrf_field()); ?>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-search-input"
                                            class="col-12 col-form-label">Role Name</label>
                                        <div class="col-12">
                                            <input type="text" name="role"
                                                value="<?php if($role): ?> <?php echo e($role->name); ?> <?php endif; ?>"
                                                class="form-control" placeholder="Role Name"
                                                value="" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="table-responsive p-2">
                                    <table class="table table-striped table-bordered table-hover">
                                        <thead class="bg-primary">
                                            <tr>
                                                <th style="color:white">SL</th>
                                                <th style="color:white">Module Name</th>
                                                <th style="color:white">Restictions <input type="checkbox"
                                                        class="form-check-input" onclick="checkAll(this)"
                                                        style="margin-left: 10px;">
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $permissionCategorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr
                                                    style="background-color:#6C8BEF; color:white;text-align:center;text-transform:capitalize;font-weight:bolder;">
                                                    <td colspan="3"><?php echo e($key); ?></td>
                                                </tr>
                                                <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissionCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($permissionCategory->id); ?></td>
                                                        <td><?php echo e($permissionCategory->title); ?></td>
                                                        <td>
                                                            <label class="" style="padding-left: 24px">
                                                                <input type="checkbox" class="form-check-input"
                                                                    name="permission[]"
                                                                    value="view <?php echo e($permissionCategory->name); ?>"
                                                                    <?php if(in_array("view $permissionCategory->name", $permissions)): ?> checked <?php endif; ?> />
                                                                <span class="custom-control-indicator"></span>
                                                                <span class="custom-control-description">View</span>
                                                            </label>
                                                            <label class="" style="padding-left: 24px">
                                                                <input type="checkbox" class="form-check-input"
                                                                    name="permission[]"
                                                                    value="edit <?php echo e($permissionCategory->name); ?>"
                                                                    <?php if(in_array("edit $permissionCategory->name", $permissions)): ?> checked <?php endif; ?> />
                                                                <span class="custom-control-indicator"></span>
                                                                <span class="custom-control-description">Edit</span>
                                                            </label>
                                                            <label class="" style="padding-left: 24px">
                                                                <input type="checkbox" class="form-check-input"
                                                                    name="permission[]"
                                                                    value="delete <?php echo e($permissionCategory->name); ?>"
                                                                    <?php if(in_array("delete $permissionCategory->name", $permissions)): ?> checked <?php endif; ?> />
                                                                <span class="custom-control-indicator"></span>
                                                                <span class="custom-control-description">Delete</span>
                                                            </label>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <center>
                                    <button type="submit" class="btn btn-success ">
                                        Update
                                    </button>
                                </center>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function checkAll(bx) {
            var cbs = document.getElementsByTagName('input');
            for (var i = 0; i < cbs.length; i++) {
                if (cbs[i].type == 'checkbox') {
                    cbs[i].checked = bx.checked;
                }
            }
        }
        $(document).ready(function() {
            $('#permission_update_form').ajaxForm({
                beforeSend: formBeforeSend,
                beforeSubmit: formBeforeSubmit,
                error: formError,
                success: function(responseText, statusText, xhr, $form) {
                    formSuccess(responseText, statusText, xhr, $form);
                },
                clearForm: false,
                resetForm: false
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.backendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\myarc\resources\views/backend/user_role.blade.php ENDPATH**/ ?>