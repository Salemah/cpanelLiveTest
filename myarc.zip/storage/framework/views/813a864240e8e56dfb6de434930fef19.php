<?php $__env->startSection('top_bar'); ?>
    <?php echo $__env->make('frontend.layers.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('frontend.layers.transparent_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section id="subheader" class="jarallax text-white">
        <img src="<?php echo e(asset('images/background/subheader.jpg')); ?>" class="jarallax-img" alt="">
        <div class="center-y relative text-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h1>Blog Single</h1>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- section close -->
    <!-- section begin -->
    <section aria-label="section">
        <div class="container">
            <div class="row">
                <div class="col-md-8">

                    <div class="blog-read">
                        <img alt="" src="<?php echo e(asset($article->image)); ?>" class="img-fullwidth">
                        <div class="post-text">
                            <p><?php echo $article->description; ?></p>
                            <blockquote><?php echo e($article->quote); ?></blockquote>
                            <p><?php echo $article->second_description; ?></p>
                            
                                <div class="d-flex flex-row mb-3">
                            <span class="post-date"><?php echo e(\Carbon\Carbon::parse($article->date)->format('M d,Y')); ?></span>
                            
                            

                                <div class="like-box">

<i id="like-<?php echo e($article->id); ?>" data-post-id="<?php echo e($article->id); ?>"
                                        class="like fa-thumbs-up <?php if(auth()->user()): ?><?php echo e(auth()->user()->hasLiked($article->id) ? 'fa-solid' : 'fa-regular'); ?> <?php else: ?> fa-regular   <?php endif; ?>"></i>


                                    <span class="like-count"><?php echo e($article->likes->count()); ?></span>
                                    
                                </div>
                                </div>


                        </div>
                    </div>
                    <div class="spacer-single"></div>
                    
                </div>
                <div id="sidebar" class="col-md-4">
                    <?php if($articles): ?>
                        <div class="widget widget-post">
                            <h4>Recent Article</h4>
                            <div class="small-border"></div>
                            <ul>
                                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><span
                                            class="date"><?php echo e(\Carbon\Carbon::parse($article->date)->format('d M')); ?></span><a
                                            href="<?php echo e(route('frontend.articles.details', ['id' => $article->id])); ?>"><?php echo e($article->title); ?></a>
                                    </li>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if($article->about_us): ?>
                        <div class="widget widget-text">
                            <h4>About Us</h4>
                            <div class="small-border"></div>
                            <p><?php echo $article->about_us; ?></p>
                        </div>
                    <?php endif; ?>
                    <?php if($tags): ?>
                        <div class="widget widget_tags">
                            <h4>Tag</h4>
                            <div class="small-border"></div>
                            <ul>
                                <?php if($tags): ?>
                                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a
                                                href="<?php echo e(route('frontend.articles.by_tag', ['id' => $tag->id])); ?>"><?php echo e($tag->name); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                                
                            </ul>
                        </div>
                    <?php endif; ?>


                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    
    <script type="text/javascript">
        $(document).ready(function() {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('.like-box i').click(function() {

                var id = $(this).attr('data-post-id');
                var boxObj = $(this).parent('div');
                var c = $(this).parent('div').find('span').text();
                var like = $(this).hasClass('like') ? 1 : 0;

                $.ajax({
                    type: 'POST',
                    url: "<?php echo e(route('posts.ajax.like.dislike')); ?>",
                    data: {
                        id: id,
                        like: like
                    },
                    success: function(data) {

                        if (data.success.hasLiked == true) {

                            if ($(boxObj).find(".dislike").hasClass("fa-solid")) {
                                var dislikes = $(boxObj).find(".dislike-count").text();
                                $(boxObj).find(".dislike-count").text(parseInt(dislikes) - 1);
                            }

                            $(boxObj).find(".like").removeClass("fa-regular");
                            $(boxObj).find(".like").addClass("fa-solid");

                            $(boxObj).find(".dislike").removeClass("fa-solid");
                            $(boxObj).find(".dislike").addClass("fa-regular");

                            var likes = $(boxObj).find(".like-count").text();
                            $(boxObj).find(".like-count").text(parseInt(likes) + 1);

                        } else if (data.success.hasDisliked == true) {

                            if ($(boxObj).find(".like").hasClass("fa-solid")) {
                                var likes = $(boxObj).find(".like-count").text();
                                $(boxObj).find(".like-count").text(parseInt(likes) - 1);
                            }

                            $(boxObj).find(".like").removeClass("fa-solid");
                            $(boxObj).find(".like").addClass("fa-regular");

                            $(boxObj).find(".dislike").removeClass("fa-regular");
                            $(boxObj).find(".dislike").addClass("fa-solid");

                            var dislike = $(boxObj).find(".dislike-count").text();
                            $(boxObj).find(".dislike-count").text(parseInt(dislike) + 1);
                        } else {
                            if ($(boxObj).find(".dislike").hasClass("fa-solid")) {
                                var dislikes = $(boxObj).find(".dislike-count").text();
                                $(boxObj).find(".dislike-count").text(parseInt(dislikes) - 1);
                            }

                            if ($(boxObj).find(".like").hasClass("fa-solid")) {
                                var likes = $(boxObj).find(".like-count").text();
                                $(boxObj).find(".like-count").text(parseInt(likes) - 1);
                            }

                            $(boxObj).find(".like").removeClass("fa-solid");
                            $(boxObj).find(".like").addClass("fa-regular");

                            $(boxObj).find(".dislike").removeClass("fa-solid");
                            $(boxObj).find(".dislike").addClass("fa-regular");

                        }
                    }
                });

            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layers.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\myarc\resources\views/frontend/article_details.blade.php ENDPATH**/ ?>