<section id="section-practice-areas">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="text-center">
                    <h2 class="wow fadeInUp">Practice Areas</h2>
                    <div class="small-border"></div>
                </div>
            </div>
            <div class="col-md-6 offset-md-3 text-center">
                <p class="wow fadeInUp">We're dedicated to offering comprehensive, expert legal services tailored to
                    meet your specific needs. Our team of seasoned attorneys brings decades of combined experience
                    across a wide array of practice areas.</p>
            </div>
            <div class="spacer-single"></div>
            <?php if($firstCategory): ?>
            <h6><?php echo e($firstCategory->name); ?></h6>
                <?php $__currentLoopData = $firstCategory->LegalArea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <ul class="ul-style-2 wow fadeInRight" data-wow-delay=".2s">
                            
                                <li><?php echo e($area->name); ?></li>
                            
                        </ul>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <hr style="width: 60%;margin:auto; " class="mb-3">
            <?php endif; ?>
            <?php if($remainingCategories): ?>

                <?php $__currentLoopData = $remainingCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $legalAreas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <h6><?php echo e($legalAreas->name); ?></h6>
                   <?php $__currentLoopData = $legalAreas->LegalArea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <ul class="ul-style-2 wow fadeInRight" data-wow-delay=".2s">
                            
                                <li><?php echo e($area->name); ?></li>
                            
                        </ul>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<section data-bgcolor="#002552" class="text-light">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-5 offset-lg-7">
                <span class="p-title">
                    <?php if($Experiences): ?>
                        <?php echo e($Experiences[0]->name); ?>

                    <?php endif; ?>
                </span><br>
                <h2>
                    <?php if($Experiences): ?>
                        <?php echo e($Experiences[0]->title); ?>

                    <?php endif; ?>
                </h2>
                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                    <?php if($Experiences): ?>
                        <?php $__currentLoopData = $Experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link <?php if($key == 0): ?> active   <?php endif; ?>" id="pills-<?php echo e($experience->id); ?>-tab" data-toggle="pill"
                                    href="#pills-<?php echo e($experience->id); ?>" role="tab"
                                    aria-controls="pills-<?php echo e($experience->id); ?>"
                                    aria-selected="true"><?php echo e($experience->tab); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    
                </ul>
                <div class="tab-content" id="pills-tabContent">
                    <?php if($Experiences): ?>
                        <?php $__currentLoopData = $Experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-pane fade <?php if($key == 0): ?> show active   <?php endif; ?>" id="pills-<?php echo e($experience->id); ?>" role="tabpanel"
                                aria-labelledby="pills-<?php echo e($experience->id); ?>-tab">
                                <p><?php echo $experience->description; ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    
                </div>
            </div>
        </div>
    </div>
    <div class="jarallax image-container col-lg-6">
        <img src="<?php if($Experiences): ?> <?php echo e(asset($Experiences[0]->image)); ?> <?php endif; ?>" class="jarallax-img"
            alt="">
    </div>
</section>
<?php /**PATH D:\laragon\www\myarc\resources\views/frontend/wedid.blade.php ENDPATH**/ ?>