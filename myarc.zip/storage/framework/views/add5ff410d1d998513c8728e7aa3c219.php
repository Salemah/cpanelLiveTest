 <section data-bgcolor="#111111" class="no-top no-bottom text-light">
     <div class="position-lg-absolute w-100">
         <div class="container">
             <div class="row g-0 align-items-center">
                 <div class="col-lg-5 offset-lg-7 ">
                     <div class="spacer-double"></div>
                     <div class="spacer-double"></div>
                     <div class="spacer-double"></div>
                     <span class="p-title wow fadeInUp" data-wow-delay=".4s">
                         <?php if($banners): ?>
                             <?php echo e($banners[0]->sub_title); ?>

                         <?php endif; ?>
                     </span><br>
                     <h1 class="wow fadeInUp" data-wow-delay=".6s">
                         <?php if($banners): ?>
                             <?php echo e($banners[0]->title); ?>

                         <?php endif; ?>
                     </h1>
                     <div class="row">
                         <div class="col-lg-10">
                             <p class="lead wow fadeInUp" data-wow-delay=".8s">
                                 <?php if($banners): ?>
                                     <?php echo $banners[0]->description; ?>

                                 <?php endif; ?>
                             </p>
                             <div class="spacer-20"></div>
                             <a class="btn-custom wow fadeInUp" data-wow-delay="1s" href="<?php echo e(route('frontend.contact')); ?>">Contact Us</a>
                         </div>
                     </div>
                     <div class="spacer-double"></div>
                     <div class="spacer-double"></div>
                 </div>
             </div>
         </div>
     </div>
     <div class="col-lg-6">
         <div class="owl-single-fade-auto owl-carousel owl-theme">
             <?php if($banners): ?>
                 <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="de-img-cap">
                         <i class="<?php echo e($banner->icon); ?>"></i>
                         <h3><?php echo e($banner->name); ?></h3>
                         <div class="d-overlay"></div>
                         <img src="<?php echo e(asset($banner->image)); ?>" class="img-fullwidth" alt="">
                     </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             <?php endif; ?>

             
         </div>
     </div>
 </section>
<?php /**PATH D:\laragon\www\myarc\resources\views/frontend/banner.blade.php ENDPATH**/ ?>