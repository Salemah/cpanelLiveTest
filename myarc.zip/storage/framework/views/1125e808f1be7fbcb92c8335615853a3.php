<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php $__env->startSection('top_bar'); ?>
    <?php echo $__env->make('frontend.layers.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('frontend.layers.transparent_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- section begin -->
    <section id="subheader" class="jarallax text-white">
        <img src="images/background/subheader2.jpg" class="jarallax-img" alt="">
        <div class="center-y relative text-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h1>Contact Us</h1>
                        <p>Reputation. Respect. Result.</p>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- section close -->
    <section aria-label="section">
        <div class="container">
            <div class="row">
                <?php if($ContactUs): ?>
                    <?php $__currentLoopData = $ContactUs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12">
                            <img src="<?php echo e(asset($contact->image)); ?>" alt="" class="img-fluid mb30">
                            <h3><?php echo e($contact->office); ?></h3>
                            <address class="s1">
                                <span><i class="id-color fa fa-map-marker fa-lg me-1"></i> <?php echo e($contact->address); ?></span>
                                <span><i class="id-color fa fa-phone fa-lg"></i><?php echo e($contact->phone); ?></span>
                                <span><i class="id-color fa fa-envelope-o fa-lg"></i><a
                                        href="mailto:<?php echo e($contact->email); ?>"><?php echo e($contact->email); ?></a></span>
                                
                            </address>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                
            </div>
        </div>
    </section>
    <section aria-label="section" class="text-light" data-bgcolor="#111111">
        <div class="container">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Successfully completed!</strong><?php echo e(session('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php elseif(session('message')): ?>
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <?php echo e(session('message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php elseif(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>Error!</strong><?php echo e(session('error')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-lg-8 offset-lg-2 mb-sm-30 text-center">
                    <h3>Do you have any question?</h3>
                    <form name="contactForm" id="contact_form" class="form-border" method="post"
                        action="<?php echo e(route('account.contact_us_message.insert')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="field-set">
                            <input type="text" name="name" id="name" class="form-control"
                                placeholder="Your Name" />
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field-set">
                            <input type="text" name="email" id="email" class="form-control"
                                placeholder="Your Email" />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field-set">
                            <input type="text" name="phone" id="phone" class="form-control"
                                placeholder="Your Phone" />
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="field-set">
                            <textarea name="message" id="message" class="form-control" placeholder="Your Message"></textarea>
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="spacer-half"></div>
                        <div id="submit">
                            <input type="submit" id="submit_form" value="Submit Form" class="btn btn-custom" />
                        </div>
                        
                    </form>
                </div>
                <div class="col-lg-4">
                </div>
            </div>
        </div>
    </section>
    <section class="jarallax text-light">
        <img src="images/background/2.jpg" class="jarallax-img" alt="">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4 col-md-12 wow fadeInRight" data-wow-delay=".2s">
                    <div class="de_count ultra-big s2 border-light text-center">
                        <h3 class="timer" data-to="20" data-speed="1000">20</h3>
                        <span class="id-color">Years of Experience</span>
                    </div>
                </div>
                <div class="col-lg-4 p-lg-5  mb-sm-30 wow fadeInRight" data-wow-delay=".4s">
                    <span class="p-title">About Us</span><br>
                    <h2>
                        <?php if($dashboard_settings): ?>
                            <?php echo e($dashboard_settings->title); ?>

                        <?php endif; ?> is Your Best Partner for Legal Solutions
                    </h2>
                </div>
                <div class="col-lg-4 wow fadeInRight" data-wow-delay=".6s">
                    <p>
                        We take pride in the depth and breadth of experience that our team of lawyers brings to the table.
                        With years of dedicated practice in various areas of law, our attorneys have honed their skills,
                        developed specialized knowledge, and earned a reputation for excellence in their respective fields.
                    </p>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('#contact_form').on('submit', function(e) {
                e.preventDefault(); // Prevent the form from submitting normally

                var formData = new FormData(this); // Serialize the form data

                $.ajax({
                    url: $(this).attr('action'), // Use the form action URL
                    type: 'POST',
                    data: formData,
                    processData: false, // Required for sending FormData
                    contentType: false, // Don't set content type header, jQuery will do that automatically
                    success: function(response) {
                        // Show success SweetAlert
                        Swal.fire({
                            icon: 'success',
                            title: 'Message Sent',
                            text: 'Your message has been sent successfully!',
                        });
                        // Optionally reset the form
                        $('#contact_form')[0].reset();
                    },
                    error: function(xhr, status, error) {
                        // Show error SweetAlert
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops!',
                            text: 'Something went wrong. Please try again.',
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layers.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\myarc\resources\views/frontend/contact_us.blade.php ENDPATH**/ ?>