<?php $__env->startSection('top_bar'); ?>
    <?php echo $__env->make('frontend.layers.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('frontend.layers.transparent_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section id="subheader" class="jarallax text-white">
        <img src="images/background/subheader3.jpg" class="jarallax-img" alt="">
        <div class="center-y relative text-center">
            <div class="container">
                <div class="row">
                    <div class="col text-center">
                        <div class="spacer-single"></div>
                        <h1>About Us</h1>
                        <p>Reputation. Respect. Result.</p>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- section close -->
    <section aria-label="section" data-bgcolor="#ffffff">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-5">
                    <span class="p-title"> <?php echo e($abouts->title); ?></span><br>
                    <h2><?php echo e($abouts->name); ?></h2>
                    <p><?php echo $abouts->description; ?></p>
                </div>
                <div class="col-md-6 offset-md-1">
                    <div class="de-images">
                        <div class="di-text text-white bg-color">
                            <?php if($abouts->cases): ?>
                                <h1><?php echo e($abouts->cases); ?></h1><span>Solved Cases</span>
                            <?php endif; ?>

                        </div>
                        <img class="di-small-2" src="<?php echo e(asset($abouts->image )); ?>" alt="<?php echo e($abouts->name); ?>" />
                        <img class="di-big img-fluid" src="<?php echo e(asset($abouts->image_two )); ?>" alt="<?php echo e($abouts->name); ?>" />
                    </div>
                </div>
            </div>
        </div>
    </section>
 <section data-bgcolor="#002552" class="text-light">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-5 offset-lg-7">
                <span class="p-title">
                    <?php if($Experiences): ?>
                        <?php echo e($Experiences[0]->name); ?>

                    <?php endif; ?>
                </span><br>
                <h2>
                    <?php if($Experiences): ?>
                        <?php echo e($Experiences[0]->title); ?>

                    <?php endif; ?>
                </h2>
                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                    <?php if($Experiences): ?>
                        <?php $__currentLoopData = $Experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link <?php if($key == 0): ?> active   <?php endif; ?>" id="pills-<?php echo e($experience->id); ?>-tab" data-toggle="pill"
                                    href="#pills-<?php echo e($experience->id); ?>" role="tab"
                                    aria-controls="pills-<?php echo e($experience->id); ?>"
                                    aria-selected="true"><?php echo e($experience->tab); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    
                </ul>
                <div class="tab-content" id="pills-tabContent">
                    <?php if($Experiences): ?>
                        <?php $__currentLoopData = $Experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-pane fade <?php if($key == 0): ?> show active   <?php endif; ?>" id="pills-<?php echo e($experience->id); ?>" role="tabpanel"
                                aria-labelledby="pills-<?php echo e($experience->id); ?>-tab">
                                <p><?php echo $experience->description; ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    
                </div>
            </div>
        </div>
    </div>
    <div class="jarallax image-container col-lg-6">
        <img src="<?php if($Experiences): ?> <?php echo e(asset($Experiences[0]->image)); ?> <?php endif; ?>" class="jarallax-img"
            alt="">
    </div>
</section>
     <section aria-label="section">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h2 class="wow fadeInUp">Our Lawyer Team</h2>
                    <div class="small-border"></div>
                </div>

                <?php if($Teams): ?>
                    <?php $__currentLoopData = $Teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 col-sm-6 mb30 wow fadeInRight" data-wow-delay=".2s">
                            <div class="f-profile text-center">
                                <div class="fp-wrap f-invert">
                                    <div class="fpw-overlay">
                                        <div class="fpwo-wrap">
                                            <div class="fpwow-icons">
                                                <a href="<?php echo e($team->facebook); ?>"><i class="fa fa-facebook fa-lg"></i></a>
                                                <a href="<?php echo e($team->twitter); ?>"><i class="fa fa-twitter fa-lg"></i></a>
                                                <a href="<?php echo e($team->linkedin); ?>"><i class="fa fa-linkedin fa-lg"></i></a>
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <div class="fpw-overlay-btm"></div>
                                    <img src="<?php echo e(asset($team->image)); ?>" class="fp-image img-fluid"
                                        alt="<?php echo e($team->name); ?> <?php echo e($team->position); ?>">
                                </div>
                                <h4><?php echo e($team->name); ?></h4>
                                <?php echo e($team->positions); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <div class="col-lg-4 col-md-6 col-sm-6 mb30 wow fadeInRight" data-wow-delay=".4s">
                    <div class="f-profile text-center">
                        <div class="fp-wrap f-invert">
                            <div class="fpw-overlay">
                                <div class="fpwo-wrap">
                                    <div class="fpwow-icons">
                                        <a href="#"><i class="fa fa-facebook fa-lg"></i></a>
                                        <a href="#"><i class="fa fa-twitter fa-lg"></i></a>
                                        <a href="#"><i class="fa fa-linkedin fa-lg"></i></a>
                                        <a href="#"><i class="fa fa-pinterest fa-lg"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="fpw-overlay-btm"></div>
                            <img src="images/team/2.jpg" class="fp-image img-fluid" alt="">
                        </div>
                        <h4>Sasha Welsh</h4>
                        Senior Partner
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 mb30 wow fadeInRight" data-wow-delay=".6s">
                    <div class="f-profile text-center">
                        <div class="fp-wrap f-invert">
                            <div class="fpw-overlay">
                                <div class="fpwo-wrap">
                                    <div class="fpwow-icons">
                                        <a href="#"><i class="fa fa-facebook fa-lg"></i></a>
                                        <a href="#"><i class="fa fa-twitter fa-lg"></i></a>
                                        <a href="#"><i class="fa fa-linkedin fa-lg"></i></a>
                                        <a href="#"><i class="fa fa-pinterest fa-lg"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="fpw-overlay-btm"></div>
                            <img src="images/team/3.jpg" class="fp-image img-fluid" alt="">
                        </div>
                        <h4>John Shepard</h4>
                        Associate
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="section-text" data-bgcolor="#111111" class="text-light">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4 col-md-12 wow fadeInRight" data-wow-delay=".2s">
                    <div class="de_count ultra-big s2 text-center">
                        <h3 class="timer" data-to="20" data-speed="1000">20</h3>
                        <span class="id-color">Years of Experience</span>
                    </div>
                </div>
                <div class="col-lg-4 p-lg-5  mb-sm-30 wow fadeInRight" data-wow-delay=".4s">
                    <span class="p-title">Welcome</span><br>
                    <h2>Justica is Your Best Partner for Legal Solutions</h2>
                </div>
                <div class="col-lg-4 wow fadeInRight" data-wow-delay=".6s">
                    <p>
                        We take pride in the depth and breadth of experience that our team of lawyers brings to the table.
                        With years of dedicated practice in various areas of law, our attorneys have honed their skills,
                        developed specialized knowledge, and earned a reputation for excellence in their respective fields.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="feature-box f-boxed style-3 text-center">
                        <i class="id-color icofont-letter"></i>
                        <div class="text">
                            <h4>Request Quote</h4>
                            Our experienced attorneys are ready to provide personalized solutions to meet your goals.
                        </div>
                        <i class="wm icofont-letter"></i>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="feature-box f-boxed style-3 text-center">
                        <i class="id-color icofont-investigation"></i>
                        <div class="text">
                            <h4>Investigation</h4>
                            Our experienced attorneys are ready to provide personalized solutions to meet your goals.
                        </div>
                        <i class="wm icofont-investigation"></i>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="feature-box f-boxed style-3 text-center">
                        <i class="id-color icofont-hand-power"></i>
                        <div class="text">
                            <h4>Case Fight</h4>
                            Our experienced attorneys are ready to provide personalized solutions to meet your goals.
                        </div>
                        <i class="wm icofont-hand-power"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layers.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\myarc\resources\views/frontend/about_us.blade.php ENDPATH**/ ?>