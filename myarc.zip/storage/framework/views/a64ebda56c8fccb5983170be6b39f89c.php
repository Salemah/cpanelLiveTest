<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <form id="remainder_insert_update" action="<?php echo e(route('admin.company.setting.insert')); ?>" accept-charset="utf-8"
        enctype="multipart/form-data" method="post" class="form-horizontal validatable">
        <?php echo csrf_field(); ?>
        <div class="row">

            <div class="card">

                <div class="card-block container py-5">
                    <div class="row">
                        <input type="hidden" name="id" value="<?php if($DashboardSetting): ?><?php echo e($DashboardSetting->id); ?><?php endif; ?>" id="hidden-id" disabled />
                        <div class="col-12 my-3">
                            <label class="form-label" for="fullname">Company Title <span class="text-danger">*</span>
                            </label>
                            <input type="text" id="title" value="<?php if($DashboardSetting): ?><?php echo e($DashboardSetting->title); ?><?php endif; ?>" name="system_title" class="form-control" placeholder="Ac..." />
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-6 my-3">
                            <label class="form-label" for="fullname">Phone <span class="text-danger">*</span> </label>
                            <input type="text" id="phone" name="phone" value="<?php if($DashboardSetting): ?><?php echo e($DashboardSetting->phone); ?><?php endif; ?>"  class="form-control"
                                placeholder="01111111111" />
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-6 my-3">
                            <label class="form-label" for="fullname">Email <span class="text-danger">*</span> </label>
                            <input type="email" id="email" name="email" value="<?php if($DashboardSetting): ?><?php echo e($DashboardSetting->email); ?><?php endif; ?>" class="form-control" placeholder="Email" />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-6 my-3">
                            <label class="form-label" for="fullname">Facebook <span class="text-danger">*</span> </label>
                            <input type="text" id="facebook" name="facebook" value="<?php if($DashboardSetting): ?><?php echo e($DashboardSetting->facebook); ?><?php endif; ?>" class="form-control"
                                placeholder="Facebook" />
                            <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-6 my-3">
                            <label class="form-label" for="fullname">Linkedin <span class="text-danger">*</span> </label>
                            <input type="text" id="linkedin" name="linkedin" value="<?php if($DashboardSetting): ?><?php echo e($DashboardSetting->linkedin); ?><?php endif; ?>" class="form-control"
                                placeholder="Linkedin" />
                            <?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-6 my-3">
                            <label class="form-label" for="fullname">Twitter <span class="text-danger">*</span> </label>
                            <input type="text" id="twitter" name="twitter" value="<?php if($DashboardSetting): ?><?php echo e($DashboardSetting->twitter); ?><?php endif; ?>" class="form-control"
                                placeholder="Twitter" />
                            <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-6 my-3">
                            <label class="form-label" for="fullname">Address <span class="text-danger">*</span> </label>
                            <input type="text" id="address" name="address" value="<?php if($DashboardSetting): ?><?php echo e($DashboardSetting->address); ?><?php endif; ?>" class="form-control"
                                placeholder="Address" />
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-6 my-3">
                            <label class="form-label" for="fullname">Copyright <span class="text-danger">*</span> </label>
                            <input type="text" id="copyright" name="copyright" value="<?php if($DashboardSetting): ?><?php echo e($DashboardSetting->copyright); ?><?php endif; ?>" class="form-control"
                                placeholder="Copyright" />
                            <?php $__errorArgs = ['copyright'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-6 my-3">
                            <label class="form-label" for="fullname">Website <span class="text-danger">*</span> </label>
                            <input type="text" id="website" name="website" value="<?php if($DashboardSetting): ?><?php echo e($DashboardSetting->website); ?><?php endif; ?>" class="form-control"
                                placeholder="Website" />
                            <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 my-3">
                            <label class="form-label" for="fullname">Description <span class="text-danger">*</span>
                            </label>
                            <input type="text" id="description" value="<?php if($DashboardSetting): ?><?php echo e($DashboardSetting->description); ?><?php endif; ?>" name="description" class="form-control"
                                placeholder="Description" />
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-6 col-sm-6 col-md-6 mb-2">
                            <label for="logo">Upload Logo<span class="text-danger">*</span></label>
                            <input type="file" id="logo" data-height="290"
                                <?php if($DashboardSetting): ?> data-default-file="<?php echo e(asset('image/dashboard/' . $DashboardSetting->logo)); ?>" <?php endif; ?>
                                class="dropify form-control <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="logo">
                            <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-6 col-sm-6 col-md-6 mb-2">
                            <label for="favicon">Upload Favicon<span class="text-danger">*</span></label>
                            <input type="file" id="favicon" data-height="290"
                                <?php if($DashboardSetting): ?> data-default-file="<?php echo e(asset('image/dashboard/' . $DashboardSetting->favicon)); ?>" <?php endif; ?>
                                class="dropify form-control " name="favicon">

                        </div>
                        <button type="submit" style="width: 10%;margin:auto" class="btn btn-primary">Submit</button>

                    </div>

                </div>
            </div>

        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            console.log('Form submitted successfully');
                $('#remainder_insert_update').ajaxForm({
                beforeSend: formBeforeSend,
                beforeSubmit: formBeforeSubmit,
                error: formError,
                success: function(responseText, statusText, xhr, $form) {
                    formSuccess(responseText, statusText, xhr, $form);
                    $('#pending_task_table').DataTable().draw(true);
                    $("#RemainderAdd").modal('hide');
                    $('#hidden-id').setAttribute("disabled");
                },
                clearForm: true,
                resetForm: true


            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.backendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\myarc\resources\views/backend/company_setting.blade.php ENDPATH**/ ?>