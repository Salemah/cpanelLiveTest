<?php $__env->startSection('css'); ?>
    <style>
        .pagination .page-item .page-link {
            padding: 10px 15px;
            margin: 0 5px;
            border-radius: 5px;
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
        }

        .pagination .page-item.active .page-link {
            background-color: #EAA636;
            color: white;
            border-color: #007bff;
        }

        .pagination .page-item .page-link:hover {
            background-color: #e9ecef;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('top_bar'); ?>
    <?php echo $__env->make('frontend.layers.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('frontend.layers.transparent_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- section begin -->
    <section id="subheader" class="jarallax text-light">
        <img src="<?php echo e(asset('images/background/subheader1.jpg')); ?>" class="jarallax-img" alt="">
        <div class="center-y relative text-center">
            <div class="container">
                <div class="row">
                    <div class="col text-center">
                        <div class="spacer-single"></div>
                        <h1>Practice Areas</h1>
                        <p>Reputation. Respect. Result.</p>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- section close -->
    <section>
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $LegalAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $LegalArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-xs-12 mb30">
                        <div class="dcg-four dcg-item">
                            <a class="dcg-url" href="<?php echo e(route('frontend.articles.by_legal_area',['id' => $LegalArea->id])); ?>"></a>
                            <img class="dcg-image" src="<?php echo e(asset($LegalArea->image)); ?>" alt="" />
                            <div class="dcg-title"><i class="<?php echo e($LegalArea->icon); ?>"></i><?php echo e($LegalArea->name); ?></div>
                            <div class="dcg-content"><?php echo $LegalArea->name; ?>

                            </div>
                            <div class="dcg-text">Read More</div>
                            <div class="dcg-overlay"></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="spacer-single"></div>
                    <?php echo e($LegalAreas->links('pagination::bootstrap-4')); ?>



                

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contact'); ?>
    <section class="pt40 pb40 bg-color text-light">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8 mb-sm-30 text-lg-start text-sm-center">
                    <h3 class="no-bottom">Contact Us Now! Get a Free Consultation for Your Case.</h3>
                </div>
                <div class="col-md-4 text-lg-right text-sm-center">
                    <a href="#" class="btn-custom btn-black light">Make Appointment</a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layers.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\myarc\resources\views/frontend/practice_area.blade.php ENDPATH**/ ?>