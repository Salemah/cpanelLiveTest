<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <h6>Personal Info</h6>
                    </div>
                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('message')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="card-block container py-2">
                    <div class="row">
                        <form class="col-sm-12" method="POST" action="<?php echo e(route('account.profile.update')); ?>"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">



                                    <div class="col-lg-6 col-md-6">
                                        <label>Email</label>
                                        <input type="text" name="email" class="form-control"
                                            value="<?php echo e($users_details->email); ?>" readonly>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                    <div class="col-lg-6 col-md-6">
                                        <label>Your Name</label>
                                        <input type="text" class="form-control" name="name"
                                            value="<?php echo e($users_details->name); ?>" required>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                    <div class="col-lg-6 col-md-6">
                                        <label>Mobile</label>
                                        <input type="text" class="form-control" name="mobile"
                                            value="<?php echo e($users_details->phone); ?>" required>
                                        <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                    <div class="col-lg-4 col-md-4">
                                        <label>Profile Picture <span class="text-danger">Size :(100*100)</span></label>
                                        <input type="file" class="form-control" name="image">
                                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <?php if($users_details->image): ?>
                                        <div class="col-lg-2 col-md-2">
                                            <img src="<?php echo e(asset($users_details->image)); ?>" class="mt-3"
                                                style="width: 40px; height:auto;" alt="Not Found!">
                                        </div>
                                    <?php else: ?>
                                        <div class="col-lg-2 col-md-2">
                                            <span>No Image!</span>
                                        </div>
                                    <?php endif; ?>

                                    
                                    


                                    <!--div class="form-group row">
                                                <div class="col-lg-6 col-md-6">
                                                <label>Subdomain</label>
                                                <input type="subdomain" class="form-control" placeholder="subdomain">
                                                </div>
                                                <div class="col-lg-6 col-md-6">
                                                <label>Service Type:</label>
                                                <input type="text" class="form-control" placeholder="Service Type:" >
                                                </div>
                                            </div-->


                                    <div class="form-group row">
                                        <div class="col-lg-12 col-md-12">
                                            <label>Address</label>
                                            <input type="text" class="form-control" name="address" placeholder="Address"
                                                value="<?php echo e($users_details->address); ?>">
                                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="error"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-lg-12 col-md-12 my-2">
                                            <center><button type="submit" class="btn btn-primary">Update Profile</button>
                                            </center>
                                        </div>
                                    </div>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.backendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\myarc\resources\views/profile/edit.blade.php ENDPATH**/ ?>