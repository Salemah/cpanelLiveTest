<!DOCTYPE html>
<html lang="zxx">


<!-- Mirrored from www.madebydesignesia.com/themes/justica/index-9.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 29 Sep 2024 15:08:37 GMT -->

<head>
    <meta charset="utf-8" />
    <title>
        <?php if($dashboard_settings): ?>
            <?php echo e($dashboard_settings->title); ?>

        <?php endif; ?>
    </title>
       <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="images/icon.png" type="image/gif" sizes="16x16">
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta
        content="<?php if($dashboard_settings): ?> <?php echo e($dashboard_settings->title); ?> <?php endif; ?> <?php if($dashboard_settings): ?> <?php echo e($dashboard_settings->about); ?> <?php endif; ?>"
        name="description" />
    <meta content="" name="keywords" />
    <meta content="" name="author" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!--[if lt IE 9]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->
    <!-- CSS Files

    ================================================== -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <?php echo $__env->make('frontend.layers.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    <div id="wrapper">
        <?php echo $__env->yieldContent('top_bar'); ?>

        <!-- header begin -->
        <?php echo $__env->yieldContent('header'); ?>
        <!-- header close -->
        <!-- content begin -->
        <div class="no-bottom no-top" id="content">
            <div id="top"></div>

            <?php echo $__env->yieldContent('content'); ?>

        </div>
        <!-- content close -->
        <a href="#" id="back-to-top"></a>
        <?php echo $__env->yieldContent('contact'); ?>
        <!-- footer begin -->
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="widget">
                            <a href="index.html"><img alt="" class="img-fluid mb20"
                                    src="<?php if($dashboard_settings): ?> <?php echo e(asset('/image/dashboard/' . $dashboard_settings->logo)); ?> <?php else: ?>  <?php echo e(asset('logo2.png')); ?> <?php endif; ?>"></a>
                            <address class="s1">
                                <span><i class="id-color fa fa-map-marker fa-lg"></i>
                                    <?php if($dashboard_settings): ?>
                                        <?php echo e($dashboard_settings->address); ?>

                                    <?php endif; ?>
                                </span>
                                <span><i class="id-color fa fa-phone fa-lg"></i>
                                    <?php if($dashboard_settings): ?>
                                        <?php echo e($dashboard_settings->phone); ?>

                                    <?php endif; ?>
                                </span>
                                <span><i class="id-color fa fa-envelope-o fa-lg"></i><a
                                        href="mailto:contact@example.com">
                                        <?php if($dashboard_settings): ?>
                                            <?php echo e($dashboard_settings->email); ?>

                                        <?php endif; ?>
                                    </a></span>
                                
                            </address>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <h4 class="id-color mb20">Area of Consultation</h4>
                        <ul class="ul-style-2">
                            <?php if($comsultationArea): ?>
                                <?php $__currentLoopData = $comsultationArea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $legalArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($legalArea->name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            
                        </ul>
                    </div>
                    <div class="col-lg-4">
                        <h4 class="id-color">Newsletter</h4>
                        <p>Signup for our newsletter to get the latest news, updates and special offers in your inbox.
                        </p>
                        <form action="https://www.madebydesignesia.com/themes/justica/blank.php" class="row"
                            id="form_subscribe" method="post" name="form_subscribe">
                            <div class="col text-center">
                                <input class="form-control" id="name_1" name="name_1" placeholder="enter your email"
                                    type="text" /> <a href="#" id="btn-submit"><i
                                        class="fa fa-long-arrow-right"></i></a>
                                <div class="clearfix"></div>
                            </div>
                        </form>
                        <div class="spacer-10"></div>
                        <small>Your email is safe with us. We don't spam.</small>
                    </div>
                </div>
            </div>
            <div class="subfooter">
                <div class="container">
                    <div class="row g-4 align-items-center">
                        <div class="col-lg-6">
                            &copy; Copyright <?php echo e(now()->year); ?> - <?php echo e($dashboard_settings->copyright); ?>

                        </div>
                        <div class="col-lg-6 text-lg-end">
                            <div class="social-icons">
                                <a href="<?php if($dashboard_settings): ?> <?php echo e($dashboard_settings->facebook); ?> <?php endif; ?>"><i
                                        class="fa fa-facebook fa-lg"></i></a>
                                <a href="<?php if($dashboard_settings): ?> <?php echo e($dashboard_settings->facebook); ?> <?php endif; ?>"><i
                                        class="fa fa-twitter fa-lg"></i></a>
                                <a
                                    href="<?php if($dashboard_settings): ?> <?php echo e($dashboard_settings->facebook); ?> <?php endif; ?>"><i
                                        class="fa fa-linkedin fa-lg"></i></a>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer close -->
        <div id="preloader">
            <div class="spinner">
                <div class="bounce1"></div>
                <div class="bounce2"></div>
                <div class="bounce3"></div>
            </div>
        </div>
    </div>

    <!-- Javascript Files
    ================================================== -->
    <?php echo $__env->make('frontend.layers.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>

</body>

</html>
<?php /**PATH D:\laragon\www\myarc\resources\views/frontend/layers/master.blade.php ENDPATH**/ ?>