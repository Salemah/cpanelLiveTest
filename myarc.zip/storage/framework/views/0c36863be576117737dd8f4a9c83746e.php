 <header class="transparent">
     <div class="container">
         <div class="row">
             <div class="col-md-12">
                 <div class="de-flex sm-pt10">
                     <div class="de-flex-col">
                         <!-- logo begin -->
                         <div id="logo">
                             <a href="index.html">
                                 <img alt="" class="logo"
                                     src="<?php if($dashboard_settings): ?> <?php echo e(asset('/image/dashboard/' . $dashboard_settings->logo)); ?> <?php else: ?>  <?php echo e(asset('logo2.png')); ?> <?php endif; ?>" />
                                 <img alt="" class="logo-2"
                                     src="<?php if($dashboard_settings): ?> <?php echo e(asset('/image/dashboard/' . $dashboard_settings->logo)); ?> <?php else: ?>  <?php echo e(asset('logo2.png')); ?> <?php endif; ?>" />
                             </a>
                         </div>
                         <!-- logo close -->
                     </div>
                     <div class="de-flex-col header-col-mid">
                         <!-- mainmenu begin -->
                         <ul id="mainmenu">
                             <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                             <li><a href="about.html">About</a>
                                 <ul>
                                     <li><a href="<?php echo e(route('frontend.about.us')); ?>">About Us</a></li>
                                     <li><a href="<?php echo e(route('frontend.our.team')); ?>">The Team</a></li>
                                     <li><a href="<?php echo e(route('frontend.faq')); ?>">FAQ</a></li>
                                 </ul>
                             </li>
                             <li><a href="<?php echo e(route('frontend.practice.area')); ?>">Practice Areas</a>
                                 <?php if($LawCategorys): ?>
                                     <ul>
                                         <?php $__currentLoopData = $LawCategorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lawCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <li><a
                                                     href="<?php echo e(route('frontend.practice.area', ['id' => $lawCategory->id])); ?>"><?php echo e($lawCategory->name); ?></a>
                                             </li>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </ul>
                                 <?php endif; ?>


                                 

                             </li>
                             <li><a href="<?php echo e(route('frontend.articles')); ?>">Articles</a>

                             </li>
                             <li><a href="<?php echo e(route('frontend.contact')); ?>">Contact</a></li>
                             <?php if(Route::has('login')): ?>


                                 <?php if(auth()->guard()->check()): ?>
                                     <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'admin')): ?>
                                         <li><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
                                     <?php endif; ?>
                                 <?php else: ?>
                                     <li><a href="<?php echo e(route('login')); ?>">Log In</a></li>
                                     <?php if(Route::has('register')): ?>
                                         <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                                     <?php endif; ?>
                                 <?php endif; ?>

                             <?php endif; ?>
                             
                         </ul>
                         <!-- mainmenu close -->
                     </div>
                     <div class="de-flex-col">
                         <div class="h-phone md-hide"><span>Need&nbsp;Help?</span><i class="fa fa-phone"></i>
                             <?php if($dashboard_settings): ?>
                                 <?php echo e($dashboard_settings->phone); ?>

                             <?php endif; ?>
                         </div>
                         <span id="menu-btn"></span>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </header>
<?php /**PATH D:\laragon\www\myarc\resources\views/frontend/layers/transparent_header.blade.php ENDPATH**/ ?>