<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('frontend.layers.transparent_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('frontend.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('frontend.reputation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('frontend.wedid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section aria-label="section">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h2 class="wow fadeInUp">Our Lawyer Team</h2>
                    <div class="small-border"></div>
                </div>

                <?php if($Teams): ?>
                    <?php $__currentLoopData = $Teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 col-sm-6 mb30 wow fadeInRight" data-wow-delay=".2s">
                            <div class="f-profile text-center">
                                <div class="fp-wrap f-invert">
                                    <div class="fpw-overlay">
                                        <div class="fpwo-wrap">
                                            <div class="fpwow-icons">
                                                <a href="<?php echo e($team->facebook); ?>"><i class="fa fa-facebook fa-lg"></i></a>
                                                <a href="<?php echo e($team->twitter); ?>"><i class="fa fa-twitter fa-lg"></i></a>
                                                <a href="<?php echo e($team->linkedin); ?>"><i class="fa fa-linkedin fa-lg"></i></a>
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <div class="fpw-overlay-btm"></div>
                                    <img src="<?php echo e(asset($team->image)); ?>" class="fp-image img-fluid"
                                        alt="<?php echo e($team->name); ?> <?php echo e($team->position); ?>">
                                </div>
                                <h4><?php echo e($team->name); ?></h4>
                                <?php echo e($team->positions); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <div class="col-lg-4 col-md-6 col-sm-6 mb30 wow fadeInRight" data-wow-delay=".4s">
                    <div class="f-profile text-center">
                        <div class="fp-wrap f-invert">
                            <div class="fpw-overlay">
                                <div class="fpwo-wrap">
                                    <div class="fpwow-icons">
                                        <a href="#"><i class="fa fa-facebook fa-lg"></i></a>
                                        <a href="#"><i class="fa fa-twitter fa-lg"></i></a>
                                        <a href="#"><i class="fa fa-linkedin fa-lg"></i></a>
                                        <a href="#"><i class="fa fa-pinterest fa-lg"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="fpw-overlay-btm"></div>
                            <img src="images/team/2.jpg" class="fp-image img-fluid" alt="">
                        </div>
                        <h4>Sasha Welsh</h4>
                        Senior Partner
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 mb30 wow fadeInRight" data-wow-delay=".6s">
                    <div class="f-profile text-center">
                        <div class="fp-wrap f-invert">
                            <div class="fpw-overlay">
                                <div class="fpwo-wrap">
                                    <div class="fpwow-icons">
                                        <a href="#"><i class="fa fa-facebook fa-lg"></i></a>
                                        <a href="#"><i class="fa fa-twitter fa-lg"></i></a>
                                        <a href="#"><i class="fa fa-linkedin fa-lg"></i></a>
                                        <a href="#"><i class="fa fa-pinterest fa-lg"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="fpw-overlay-btm"></div>
                            <img src="images/team/3.jpg" class="fp-image img-fluid" alt="">
                        </div>
                        <h4>John Shepard</h4>
                        Associate
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section aria-label="section" class="jarallax text-light">
        <img src="images/background/3.jpg" class="jarallax-img" alt="">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-center text-light">
                        <h2 class="wow fadeInUp">Testimonials</h2>
                        <div class="small-border"></div>
                    </div>
                    <div class="owl-carousel owl-theme" id="testimonial-carousel">
                        <?php if($Testimonials): ?>
                            <?php $__currentLoopData = $Testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonials): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item">
                                    <div class="de_testi opt-2 review">
                                        <blockquote style="min-height: 20vh !important">
                                            <i class="fa fa-quote-left id-color"></i>
                                            <h3><?php echo e($testimonials->title); ?></h3>
                                            <p><?php echo $testimonials->description; ?> </p>
                                            <div class="de_testi_by"><span><?php echo e($testimonials->quote_by); ?></span></div>
                                        </blockquote>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php if($Articles): ?>
        <section aria-label="section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="text-center">
                            <h2 class="wow fadeInUp">Latest News</h2>
                            <div class="small-border"></div>
                        </div>
                    </div>
                </div>
                <div class="row">

                    <?php $__currentLoopData = $Articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 mb30">
                            <a href="<?php echo e(route('frontend.articles.details', ['id' => $article->id])); ?>">
                                <div class="bloglist item">
                                    <div class="post-content">
                                        <div class="date-box">
                                            <div class="m"><?php echo e(\Carbon\CarboN::parse($article->date)->format('d')); ?>

                                            </div>
                                            <div class="d"><?php echo e(\Carbon\Carbon::parse($article->date)->format('M')); ?>

                                            </div>
                                        </div>
                                        <div class="post-image">
                                            <img alt="<?php echo e($article->title); ?>" src="<?php echo e(asset($article->image)); ?>">
                                        </div>
                                        <div class="post-text">
                                            <span class="p-tagline"><?php echo e($article->LegalArea->lawCategory ? $article->LegalArea->lawCategory->name : 'Law Firm'); ?></span>
                                            <h4><?php echo e($article->title); ?><span></span></h4>
                                            <p><?php echo \Illuminate\Support\Str::limit($article->description, 100); ?></p>
                                            <span class="p-author"><?php echo e($article->User ? $article->User->name : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                    
                </div>
            </div>
        </section>
    <?php endif; ?>

    <section class="pt40 pb40 bg-color text-light">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8 mb-sm-30 text-lg-start text-sm-center wow fadeInRight">
                    <h3 class="no-bottom">Contact Us Now! Get a Free Consultation for Your Case.</h3>
                </div>
                <div class="col-md-4 text-lg-end rtl-lg-start text-sm-center wow fadeInRight">
                    <a href="<?php echo e(route('frontend.make_appointment')); ?>" class="btn-custom btn-black text-white light">Make Appointment</a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layers.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\myarc\resources\views/frontend/home.blade.php ENDPATH**/ ?>