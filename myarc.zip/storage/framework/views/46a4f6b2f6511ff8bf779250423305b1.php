   <section id="section-highlight" class="relative text-light" data-bgcolor="#002552">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-4">
                            <span class="p-title wow fadeInUp">Welcome</span><br>
                            <h2 class="wow fadeInUp">
                                 <?php if($Reputations): ?>
                             <?php echo e($Reputations[0]->title); ?>

                         <?php endif; ?>
                            </h2>
                            <div class="small-border sm-left"></div>
                        </div>
                        <div class="col-md-8">
                            <p class="wow fadeInRight"> <?php if($Reputations): ?>
                             <?php echo $Reputations[0]->description; ?>

                         <?php endif; ?>
                            </p>
                        </div>
                    </div>
                    <div class="spacer-double"></div>
                </div>
            </section>
             <section class="no-top relative z1000">
                <div class="container">
                    <div class="row mt-100">
                          <?php if($Reputations): ?>
                 <?php $__currentLoopData = $Reputations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Reputation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="col-md-4 mb-sm-30 wow fadeInRight" data-wow-delay=".6s">
                            <div class="mask">
                                <div class="cover">
                                    <div class="c-inner">
                                        <h3><i class="<?php echo e($Reputation->icon); ?>"></i><span><?php echo e($Reputation->name); ?></span></h3>
                                       <p><?php echo $Reputation->law_details; ?></p>
                                        <div class="spacer20"></div>
                                        <a href="#" class="btn-custom capsule">Read more</a>
                                    </div>
                                </div>
                                <img src="<?php echo e(asset($Reputation->image)); ?>" alt="<?php echo e(asset($Reputation->name)); ?>" class="img-responsive" />
                            </div>
                        </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             <?php endif; ?>

                        
                    </div>
                </div>
            </section>
<?php /**PATH D:\laragon\www\myarc\resources\views/frontend/reputation.blade.php ENDPATH**/ ?>