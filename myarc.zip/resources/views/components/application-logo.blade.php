<img src="@if ($dashboard_settings) {{ asset('/image/dashboard/' . $dashboard_settings->logo) }} @else  {{ asset('logo2.png') }} @endif"
    alt="Logo" style="height: 100px;">
